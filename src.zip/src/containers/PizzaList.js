import React, { Component } from 'react';
import Pizza from '../components/Pizza'
import PizzaForm from '../components/PizzaForm'
class PizzaList extends Component {


  renderPizza = () => {
   
    const clicker = (top, size, veg) => {
     console.log('top' + top);
      <PizzaForm top={top} size={size} veg={veg}></PizzaForm>
  
      
    }

    return this.props.data.map(piza => {
      return (
        <Pizza clicker={()=>clicker(piza.topping, piza.size, piza.vegetarian)} id={piza.id} topping={piza.topping} size={piza.size} vegetarian={piza.vegetarian ? 'Yes' : 'No'} />

      )
    })
  }


  handleEdit = (id) => {

  }
  render() {
    return (
      <table className="table table-striped">
        <thead>
          <tr>
            <th scope="col">Topping</th>
            <th scope="col">Size</th>
            <th scope="col">Vegetarian?</th>
            <th scope="col">Edit</th>
          </tr>
        </thead>
        <tbody>
          {
            this.renderPizza()
          }
        </tbody>
      </table>
    );
  }

}

export default PizzaList;

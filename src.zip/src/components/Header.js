import React, { Component, Fragment } from 'react';

class Header extends Component {

  render() {
    return (
      <Fragment>
        <h1 className="text-center">Welcome to Flatiron School's Pizzeria</h1>
      </Fragment>
    );
  }

}

export default Header;
